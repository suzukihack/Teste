import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import authRouter from './routes/auth.js';
import redacoesRouter from './routes/redacoes.js';
import adminRouter from './routes/admin.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

app.use('/public', express.static(path.join(__dirname, '../../public')));

app.get('/api/healthz', (_req, res) => { res.json({ status: 'ok' }); });

app.use('/api', authRouter);
app.use('/api', redacoesRouter);
app.use('/api', adminRouter);

app.listen(PORT, () => { console.log('RedaAI Backend running on port ' + PORT); });
