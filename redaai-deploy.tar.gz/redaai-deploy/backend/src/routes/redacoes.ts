import { Router, type IRouter } from "express";
import axios from "axios";
import {
  ListRedacoesQueryParams,
  ListRedacoesResponseItem,
  CompletarRedacaoBody,
  CompletarRedacaoResponse,
  GetRedacaoStatusQueryParams,
  GetRedacaoStatusResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const API_BASE = "https://edusp-api.ip.tv";
const AI_URL   = "https://api-dos-jack.shardweb.app/chat";

interface SessionData {
  ra: string;
  nick: string;
  authToken: string;
  targets: string[];
  slugs: string[];
}

function decodeSession(sessionToken: string): SessionData | null {
  try {
    return JSON.parse(Buffer.from(sessionToken, "base64").toString("utf-8")) as SessionData;
  } catch {
    return null;
  }
}

function makeHeaders(authToken: string) {
  return {
    "accept":           "application/json",
    "accept-language":  "pt-BR,pt;q=0.7",
    "cache-control":    "no-cache",
    "content-type":     "application/json",
    "x-api-key":        authToken,
    "x-api-platform":   "webclient",
    "x-api-realm":      "edusp",
    "x-authorization":  "SHA1 null",
    "origin":           "https://saladofuturo.educacao.sp.gov.br",
    "referer":          "https://saladofuturo.educacao.sp.gov.br/",
    "user-agent":       "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36"
  };
}

function stripHtml(s: string): string {
  return (s || "").replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim();
}

function formatDate(iso: string): string {
  if (!iso) return "";
  try {
    return new Date(iso).toLocaleDateString("pt-BR", {
      day: "2-digit", month: "2-digit", year: "numeric"
    });
  } catch { return ""; }
}

router.get("/redacoes", async (req, res) => {
  const parsed = ListRedacoesQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "sessionToken obrigatório" });
    return;
  }

  const session = decodeSession(parsed.data.sessionToken);
  if (!session) {
    res.status(401).json({ error: "Sessão inválida. Faça login novamente." });
    return;
  }

  try {
    const params = new URLSearchParams();
    params.append("expired_only",      "false");
    params.append("limit",             "100");
    params.append("offset",            "0");
    params.append("filter_expired",    "true");
    params.append("is_exam",           "false");
    params.append("with_answer",       "true");
    params.append("is_essay",          "true");
    params.append("with_apply_moment", "true");
    params.append("answer_statuses",   "draft");
    params.append("answer_statuses",   "pending");
    for (const t of session.targets) params.append("publication_target", t);

    const essaysRes = await axios.get(`${API_BASE}/tms/task/todo?${params}`, {
      headers: makeHeaders(session.authToken),
      timeout: 20000,
      validateStatus: () => true,
    });

    if (essaysRes.status !== 200) {
      res.json([]);
      return;
    }

    const rawEssays = Array.isArray(essaysRes.data)
      ? essaysRes.data
      : (essaysRes.data.tasks || essaysRes.data.data || []);

    const redacoes = rawEssays.map((task: Record<string, unknown>) => {
      const answer = (task.answer || {}) as Record<string, unknown>;
      const applyMoment = (task.apply_moment || {}) as Record<string, unknown>;
      const status = answer.status === "draft"
        ? "Rascunho"
        : answer.status === "pending" || !answer.status
          ? "Pendente"
          : String(answer.status);

      const descText = stripHtml(String(task.description || "")).substring(0, 300);
      const endDate = String(applyMoment.end_date || task.end_date || "");
      const startDate = String(applyMoment.start_date || task.start_date || "");

      return ListRedacoesResponseItem.parse({
        id:        String(task.id || task.task_id || ""),
        titulo:    String(task.title || task.name || "Redação sem título"),
        status,
        dataEnvio: endDate ? formatDate(endDate) : formatDate(startDate),
        tema:      descText || null,
        nota:      answer.grade != null ? String(answer.grade) : null,
        descricao: JSON.stringify({ 
          answerId: (answer as Record<string,unknown>).id || (answer as Record<string,unknown>).answer_id || null,
          taskRaw: task 
        }),
      });
    });

    res.json(redacoes);
  } catch (err) {
    req.log.error({ err }, "Failed to list redacoes");
    res.status(500).json({ error: "Erro ao buscar redações" });
  }
});

async function applyTask(authToken: string, taskId: string, slugs: string[]) {
  const attempts = [...slugs, ""];
  for (const slug of attempts) {
    try {
      const url = `${API_BASE}/tms/task/${taskId}/apply?preview_mode=false&token_code=null&room_name=${encodeURIComponent(slug)}`;
      const res = await axios.get(url, {
        headers: makeHeaders(authToken),
        timeout: 15000,
        validateStatus: () => true,
      });
      if (res.status >= 200 && res.status < 300) {
        return res.data;
      }
    } catch { continue; }
  }
  return null;
}

function buildPrompt(task: Record<string, unknown>): string {
  const title = String(task.title || "");
  const questions = (task.questions || []) as Array<Record<string,unknown>>;
  const desc = stripHtml(String(task.description || ""));

  const q = questions.find((x: Record<string,unknown>) =>
    x.type === "text_ai" || x.type === "essay" || x.type === "text"
  ) || questions[0] || {};

  const statement = q ? stripHtml(String((q as Record<string,unknown>).statement || "")) : "";
  const opts      = (q ? ((q as Record<string,unknown>).options || {}) : {}) as Record<string,unknown>;
  const genre     = opts.genre ? String((opts.genre as Record<string,unknown>).statement || "") : "";
  const support   = stripHtml(String(opts.support_text || ""));
  const minChars  = Number(opts.min_word_count || opts.min_text_count || 800);
  const maxChars  = Math.min(Number(opts.max_word_count || opts.max_text_count || 1900), 1900);
  const keywords  = ((opts.ai_grading_keywords as string[]) || []).join(", ");

  const lines = [
    "Você é um estudante brasileiro do ensino médio escrevendo uma redação escolar.",
    "",
  ];
  if (title)     lines.push("Título da atividade: " + title);
  if (genre)     lines.push("Gênero textual: " + genre);
  if (support)   lines.push("Modelo do gênero: " + support.substring(0, 3000));
  if (desc)      lines.push("Descrição: " + desc);
  if (statement) lines.push("Enunciado: " + statement.substring(0, 4000));
  if (keywords)  lines.push("Palavras-chave obrigatórias: " + keywords);
  lines.push(
    `LIMITE ESTRITO: o texto deve ter entre ${minChars} e ${maxChars} caracteres.`,
    "",
    "INSTRUÇÕES:",
    "1. Na PRIMEIRA linha escreva APENAS o título da redação",
    "2. Pule uma linha em branco",
    "3. Escreva a redação completa",
    "4. Linguagem natural de estudante do ensino médio",
    "5. NÃO use: destarte, outrossim, é mister, hodiernamente",
    "",
    "Resposta EXATA:",
    "[Título]",
    "",
    "[Texto completo]"
  );
  return lines.join("\n");
}

router.post("/redacoes/completar", async (req, res) => {
  const parsed = CompletarRedacaoBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Dados inválidos" });
    return;
  }

  const { id: taskId, sessionToken } = parsed.data;
  const session = decodeSession(sessionToken);
  if (!session) {
    res.status(401).json({ error: "Sessão inválida. Faça login novamente." });
    return;
  }

  try {
    // Step 1: Apply task
    const applied = await applyTask(session.authToken, taskId, session.slugs);
    if (!applied) {
      res.status(400).json({ error: "Não foi possível abrir a redação. Tente novamente." });
      return;
    }

    // Step 2: Find essay question
    const questions = (applied.questions || []) as Array<Record<string,unknown>>;
    const q = questions.find((x: Record<string,unknown>) =>
      x.type === "essay" || x.type === "text_ai" || x.type === "text"
    ) || questions[0];

    if (!q) {
      res.status(400).json({ error: "Questão de redação não encontrada." });
      return;
    }

    // Step 3: Generate AI text
    const prompt = buildPrompt({ ...applied, questions });
    let aiText = "";
    try {
      const aiRes = await axios.post(AI_URL,
        { texto: prompt },
        {
          headers: { "Content-Type": "application/json; charset=utf-8" },
          timeout: 60000,
          validateStatus: () => true,
        }
      );
      if (aiRes.status === 200) {
        const d = aiRes.data as Record<string, unknown>;
        aiText = String(d.resposta || d.response || d.message || d.text || d.content || "");
      }
    } catch (e) {
      req.log.error({ e }, "AI call failed");
    }

    if (!aiText) {
      res.status(500).json({ error: "A IA não retornou texto. Tente novamente." });
      return;
    }

    // Step 4: Parse title + body
    let lines = aiText.trim().split("\n");
    while (lines.length && !lines[0].trim()) lines.shift();
    let essayTitle = "";
    let essayBody  = aiText.trim();
    if (lines.length >= 2) {
      essayTitle = lines[0].trim().replace(/^["']|["']$/g, "");
      essayBody  = lines.slice(1).join("\n").trim();
      if (!essayBody) { essayBody = aiText.trim(); essayTitle = ""; }
    }

    // Step 5: Save as draft
    const answerId = applied.answer?.id || applied.answer?.answer_id || null;
    const questionIdStr = String((q as Record<string,unknown>).id);
    const answers: Record<string, unknown> = {};
    answers[questionIdStr] = {
      question_id:   (q as Record<string,unknown>).id,
      question_type: "essay",
      answer: { title: essayTitle, body: essayBody }
    };

    const payload = {
      status:      "draft",
      answers,
      accessed_on: "room",
      executed_on: Date.now(),
      duration:    parseFloat((20 + Math.random() * 15).toFixed(2))
    };

    const saveUrl = answerId
      ? `${API_BASE}/tms/task/${taskId}/answer/${answerId}`
      : `${API_BASE}/tms/task/${taskId}/answer`;
    const saveMethod = answerId ? "put" : "post";

    const saveRes = await (axios[saveMethod] as typeof axios.post)(saveUrl, payload, {
      headers: makeHeaders(session.authToken),
      timeout: 20000,
      validateStatus: () => true,
    });

    const success = saveRes.status >= 200 && saveRes.status < 300;

    const data = CompletarRedacaoResponse.parse({
      success,
      message: success
        ? "Redação gerada e salva como rascunho com sucesso!"
        : "Redação gerada mas houve erro ao salvar.",
      status: success ? "done" : "error",
    });
    res.json(data);
  } catch (err) {
    req.log.error({ err }, "Failed to completar redacao");
    res.status(500).json({ error: "Erro ao processar redação. Tente novamente." });
  }
});

router.get("/redacoes/status", async (req, res) => {
  const parsed = GetRedacaoStatusQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Parâmetros inválidos" });
    return;
  }

  const data = GetRedacaoStatusResponse.parse({
    status: "done",
    message: "Redação concluída!",
    done: true,
  });
  res.json(data);
});

export default router;
