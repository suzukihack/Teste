import { Router, type IRouter } from "express";
import fs from "fs/promises";
import path from "path";
import {
  GetAdminSettingsResponse,
  UpdateAdminSettingsBody,
  UpdateAdminSettingsResponse,
  UploadCreatorImageBody,
  UploadCreatorImageResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const SETTINGS_FILE = path.resolve(process.cwd(), "data/admin-settings.json");
const UPLOADS_DIR = path.resolve(process.cwd(), "data/uploads");

const DEFAULT_SETTINGS = {
  siteName: "RedaAI",
  primaryColor: "#e01c1c",
  footerText: "Nami e tree script",
  creator1Name: "Nami",
  creator1Image: null as string | null,
  creator2Name: "JK",
  creator2Image: null as string | null,
};

async function ensureDataDir() {
  await fs.mkdir(path.dirname(SETTINGS_FILE), { recursive: true });
  await fs.mkdir(UPLOADS_DIR, { recursive: true });
}

async function loadSettings(): Promise<typeof DEFAULT_SETTINGS> {
  try {
    const raw = await fs.readFile(SETTINGS_FILE, "utf-8");
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

async function saveSettings(settings: typeof DEFAULT_SETTINGS) {
  await ensureDataDir();
  await fs.writeFile(SETTINGS_FILE, JSON.stringify(settings, null, 2), "utf-8");
}

router.get("/admin/settings", async (_req, res) => {
  const settings = await loadSettings();
  const data = GetAdminSettingsResponse.parse(settings);
  res.json(data);
});

router.put("/admin/settings", async (req, res) => {
  const parsed = UpdateAdminSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Dados inválidos" });
    return;
  }

  const current = await loadSettings();
  const updated = { ...current, ...parsed.data };
  await saveSettings(updated);

  const data = UpdateAdminSettingsResponse.parse(updated);
  res.json(data);
});

router.post("/admin/upload-creator", async (req, res) => {
  const parsed = UploadCreatorImageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Dados inválidos" });
    return;
  }

  const { creatorIndex, imageBase64 } = parsed.data;

  try {
    await ensureDataDir();

    const base64Data = imageBase64.replace(/^data:image\/[a-z]+;base64,/, "");
    const ext = imageBase64.match(/^data:image\/([a-z]+);base64,/)?.[1] || "png";
    const fileName = `creator${creatorIndex}.${ext}`;
    const filePath = path.join(UPLOADS_DIR, fileName);

    await fs.writeFile(filePath, Buffer.from(base64Data, "base64"));

    const imageUrl = `/api/admin/creator-image/${fileName}`;

    const current = await loadSettings();
    if (creatorIndex === 1) {
      current.creator1Image = imageUrl;
    } else {
      current.creator2Image = imageUrl;
    }
    await saveSettings(current);

    const data = UploadCreatorImageResponse.parse({
      success: true,
      imageUrl,
    });
    res.json(data);
  } catch (err) {
    req.log.error({ err }, "Failed to upload creator image");
    res.status(500).json({ error: "Erro ao fazer upload" });
  }
});

router.get("/admin/creator-image/:fileName", async (req, res) => {
  const { fileName } = req.params;
  const safeName = path.basename(fileName);
  const filePath = path.join(UPLOADS_DIR, safeName);

  try {
    const data = await fs.readFile(filePath);
    const ext = path.extname(safeName).slice(1);
    res.setHeader("Content-Type", `image/${ext}`);
    res.send(data);
  } catch {
    res.status(404).json({ error: "Imagem não encontrada" });
  }
});

export default router;
