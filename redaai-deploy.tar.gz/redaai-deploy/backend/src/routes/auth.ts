import { Router, type IRouter } from "express";
import axios from "axios";
import { LoginUserBody, LoginUserResponse } from "@workspace/api-zod";

const router: IRouter = Router();

const API_BASE   = "https://edusp-api.ip.tv";
const WORKER_URL = "https://muddy-wood-f94e.iagosantosrocha67.workers.dev/";

function normalizeRA(raw: string): string {
  if (!raw) return "";
  const trimmed = raw.trim();
  const m = trimmed.match(/^(\d+)([a-zA-Z]{2})$/);
  if (m) return m[1].padStart(13, "0") + m[2].toUpperCase();
  const clean = trimmed.toUpperCase().replace(/[^0-9A-Z]/g, "");
  if (clean.length >= 10) return clean;
  return trimmed;
}

function makeHeaders(authToken: string) {
  return {
    "accept":           "application/json",
    "accept-language":  "pt-BR,pt;q=0.7",
    "cache-control":    "no-cache",
    "content-type":     "application/json",
    "x-api-key":        authToken,
    "x-api-platform":   "webclient",
    "x-api-realm":      "edusp",
    "x-authorization":  "SHA1 null",
    "origin":           "https://saladofuturo.educacao.sp.gov.br",
    "referer":          "https://saladofuturo.educacao.sp.gov.br/",
    "pragma":           "no-cache",
    "user-agent":       "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36"
  };
}

async function fetchRooms(authToken: string, nick: string): Promise<{ targets: string[]; slugs: string[] }> {
  const empty = { targets: [], slugs: [] };
  try {
    const res = await axios.get(`${API_BASE}/room/user?list_all=true&with_cards=true`, {
      headers: makeHeaders(authToken),
      timeout: 15000,
    });
    if (res.status !== 200) return empty;

    const data  = res.data;
    const rooms = data.rooms || (Array.isArray(data) ? data : []);
    const targets: string[] = [];
    const seen = new Set<string>();
    const slugs: string[] = [];

    const addTarget = (val: unknown) => {
      const s = String(val);
      if (!seen.has(s)) { seen.add(s); targets.push(s); }
    };

    for (const r of rooms) {
      const room = (typeof r.room === "object" && r.room) ? r.room : {};
      const name = r.name || r.room_name || r.code || room.room_name || room.name || "";
      const id   = r.id || room.id;

      if (name) {
        addTarget(name);
        if (nick) addTarget(name + ":" + nick);
        if (/^r[0-9a-f]+-l$/i.test(name)) slugs.push(name);
      }
      if (id != null) addTarget(id);

      for (const gc of r.group_categories || []) {
        if (gc && gc.id != null) addTarget(gc.id);
      }
      for (const key of ["publication_id", "class_id", "group_id", "category_id"]) {
        const v = r[key] || room[key];
        if (v != null) addTarget(v);
      }
    }
    return { targets, slugs };
  } catch {
    return empty;
  }
}

router.post("/auth/login", async (req, res) => {
  const parsed = LoginUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Dados de login inválidos" });
    return;
  }

  const { ra, password } = parsed.data;
  const normalizedRA = normalizeRA(ra);

  try {
    // Step 1: Worker login (SED)
    let workerData: { success?: boolean; sed_token?: string; error?: string };
    try {
      const workerRes = await axios.post(WORKER_URL, { ra: normalizedRA, senha: password }, {
        headers: { "Content-Type": "application/json" },
        timeout: 20000,
        validateStatus: () => true,
      });
      workerData = workerRes.data;
    } catch (e) {
      req.log.error({ e }, "Worker request failed");
      res.status(401).json({ error: "Erro ao conectar com o sistema SED. Verifique sua internet." });
      return;
    }

    if (!workerData.success || !workerData.sed_token) {
      res.status(401).json({ error: workerData.error || "Login falhou. Verifique RA e senha." });
      return;
    }

    // Step 2: EDUSP auth token
    let eduspData: { auth_token?: string; nick?: string; nickname?: string; login?: string; error?: string };
    try {
      const eduspRes = await axios.post(`${API_BASE}/registration/edusp/token`,
        { token: workerData.sed_token },
        {
          headers: {
            "Content-Type":  "application/json",
            "Accept":         "application/json",
            "x-api-realm":   "edusp",
            "x-api-platform":"webclient",
            "origin":        "https://saladofuturo.educacao.sp.gov.br",
            "referer":       "https://saladofuturo.educacao.sp.gov.br/",
          },
          timeout: 20000,
          validateStatus: () => true,
        }
      );
      eduspData = eduspRes.data;
    } catch (e) {
      req.log.error({ e }, "EDUSP auth failed");
      res.status(401).json({ error: "Erro ao autenticar no EDUSP. Tente novamente." });
      return;
    }

    const authToken = (eduspData.auth_token || "").trim();
    const nick = eduspData.nick || eduspData.nickname || eduspData.login || normalizedRA;

    if (!authToken) {
      res.status(401).json({ error: eduspData.error || "Credenciais inválidas. Verifique RA e senha." });
      return;
    }

    // Step 3: Fetch rooms for targets/slugs
    const { targets, slugs } = await fetchRooms(authToken, nick);

    // Build session token as base64-encoded JSON
    const sessionObj = { ra: normalizedRA, nick, authToken, targets, slugs };
    const sessionToken = Buffer.from(JSON.stringify(sessionObj)).toString("base64");

    const data = LoginUserResponse.parse({
      success: true,
      sessionToken,
      userName: nick,
      ra: normalizedRA,
      message: null,
    });

    res.json(data);
  } catch (err: unknown) {
    req.log.error({ err }, "Login failed");
    const msg = err instanceof Error ? err.message : "Erro inesperado";
    res.status(500).json({ error: `Erro no servidor: ${msg}` });
  }
});

export { makeHeaders, normalizeRA };
export default router;
