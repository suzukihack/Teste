import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { useSettings } from "@/lib/settings";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Layout({ children }: { children: React.ReactNode }) {
  const { settings } = useSettings();
  const { isAuthenticated, userName, logout } = useAuth();
  const [, setLocation] = useLocation();

  const [clicks, setClicks] = useState(0);
  const [lastClick, setLastClick] = useState(0);

  useEffect(() => {
    const disableContextMenu = (e: MouseEvent) => e.preventDefault();
    const disableDevTools = (e: KeyboardEvent) => {
      if (e.key === "F12") { e.preventDefault(); return; }
      if ((e.ctrlKey || e.metaKey) && ['u', 'U', 'i', 'I', 's', 'S'].includes(e.key)) {
        e.preventDefault();
      }
    };
    document.addEventListener("contextmenu", disableContextMenu);
    document.addEventListener("keydown", disableDevTools);
    return () => {
      document.removeEventListener("contextmenu", disableContextMenu);
      document.removeEventListener("keydown", disableDevTools);
    };
  }, []);

  const handleTitleClick = () => {
    const now = Date.now();
    if (now - lastClick > 2000) {
      setClicks(1);
    } else {
      const next = clicks + 1;
      setClicks(next);
      if (next >= 5) {
        const pwd = prompt("Senha Admin:");
        if (pwd === "1704") {
          setLocation("/admin");
        }
        setClicks(0);
      }
    }
    setLastClick(now);
  };

  const handleLogout = () => {
    logout();
    setLocation("/");
  };

  const primaryColor = settings?.primaryColor || "#e01c1c";

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background selection:bg-primary/20">
      <header className="sticky top-0 z-50 w-full border-b border-border/60 bg-card/80 backdrop-blur-md">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div
            className="text-2xl font-extrabold tracking-tight cursor-pointer select-none transition-all"
            style={{
              color: primaryColor,
              textShadow: `0 0 16px ${primaryColor}99, 0 0 32px ${primaryColor}44`,
            }}
            onClick={handleTitleClick}
          >
            {settings?.siteName || "RedaAI"}
          </div>

          {isAuthenticated && (
            <div className="flex items-center gap-3">
              <span className="text-sm font-medium text-muted-foreground hidden sm:inline-block px-3 py-1 rounded-full bg-muted/50 border border-border/50">
                Olá, <span className="text-foreground font-semibold">{userName}</span>
              </span>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleLogout}
                className="text-muted-foreground hover:text-foreground hover:bg-muted/50 rounded-full"
              >
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
      </header>

      <main className="flex-1 flex flex-col relative">
        {children}
      </main>

      <footer className="border-t border-border/40 py-8 mt-auto bg-card/60 backdrop-blur-sm">
        <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-6">
          <p className="text-sm text-muted-foreground font-medium">
            {settings?.footerText || "Nami e tree script"}
          </p>

          <div className="flex items-center gap-8">
            <div className="flex flex-col items-center gap-2">
              <Avatar
                className="h-14 w-14 border-2 shadow-lg"
                style={{ borderColor: `${primaryColor}55` }}
              >
                <AvatarImage
                  src={settings?.creator1Image || "/nami.jpg"}
                  alt={settings?.creator1Name || "Nami"}
                  className="object-cover"
                />
                <AvatarFallback className="bg-primary/10 text-primary text-sm font-bold">NM</AvatarFallback>
              </Avatar>
              <span className="text-xs font-semibold text-muted-foreground">
                {settings?.creator1Name || "Nami"}
              </span>
            </div>
            <div className="flex flex-col items-center gap-2">
              <Avatar
                className="h-14 w-14 border-2 shadow-lg"
                style={{ borderColor: `hsl(340 80% 55% / 0.4)` }}
              >
                <AvatarImage
                  src={settings?.creator2Image || "/jk.jpg"}
                  alt={settings?.creator2Name || "JK"}
                  className="object-cover"
                />
                <AvatarFallback
                  className="text-sm font-bold"
                  style={{ background: "hsl(340 80% 18%)", color: "hsl(340 80% 65%)" }}
                >
                  JK
                </AvatarFallback>
              </Avatar>
              <span className="text-xs font-semibold text-muted-foreground">
                {settings?.creator2Name || "JK"}
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
