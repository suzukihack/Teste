type ErrorType<T> = T & { status: number; statusText: string; data: unknown; headers: Record<string, string> };
export type SecondParameter<T extends (...args: never) => unknown> = Parameters<T>[1];
export const customFetch = async <T>(url: string, options?: RequestInit): Promise<T> => {
  const res = await fetch(url, options);
  if (!res.ok) {
    const error = new Error(res.statusText) as ErrorType<Error>;
    error.status = res.status; error.statusText = res.statusText;
    try { (error as unknown as {data: unknown}).data = await res.json(); } catch { (error as unknown as {data: unknown}).data = null; }
    throw error;
  }
  return res.json();
};
export type { ErrorType };
