import { createContext, useContext, useEffect, ReactNode } from "react";
import { useGetAdminSettings } from "@/api";
import type { AdminSettings } from "@/api";

interface SettingsContextType {
  settings: AdminSettings | undefined;
  isLoading: boolean;
}

const SettingsContext = createContext<SettingsContextType>({ settings: undefined, isLoading: true });

function hexToHsl(hex: string): string | null {
  // Simple hex to HSL parser for CSS vars
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  if (!result) return null;
  const r = parseInt(result[1], 16) / 255;
  const vG = parseInt(result[2], 16) / 255;
  const b = parseInt(result[3], 16) / 255;

  const max = Math.max(r, vG, b), min = Math.min(r, vG, b);
  let h = 0, s = 0, l = (max + min) / 2;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = (vG - b) / d + (vG < b ? 6 : 0); break;
      case vG: h = (b - r) / d + 2; break;
      case b: h = (r - vG) / d + 4; break;
    }
    h /= 6;
  }
  return `${Math.round(h * 360)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
}

export function SettingsProvider({ children }: { children: ReactNode }) {
  const { data: settings, isLoading } = useGetAdminSettings();

  useEffect(() => {
    if (settings?.primaryColor) {
      const hsl = hexToHsl(settings.primaryColor);
      if (hsl) {
        document.documentElement.style.setProperty('--primary', hsl);
        document.documentElement.style.setProperty('--ring', hsl);
      }
    } else {
      document.documentElement.style.removeProperty('--primary');
      document.documentElement.style.removeProperty('--ring');
    }
  }, [settings?.primaryColor]);

  return (
    <SettingsContext.Provider value={{ settings, isLoading }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  return useContext(SettingsContext);
}
