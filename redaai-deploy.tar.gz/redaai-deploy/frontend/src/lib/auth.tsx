import { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface AuthState {
  sessionToken: string | null;
  userName: string | null;
  ra: string | null;
}

interface AuthContextType extends AuthState {
  login: (token: string, name: string, ra: string) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [auth, setAuth] = useState<AuthState>(() => {
    const sessionToken = localStorage.getItem("auth_sessionToken");
    const userName = localStorage.getItem("auth_userName");
    const ra = localStorage.getItem("auth_ra");
    return { sessionToken, userName, ra };
  });

  const login = (sessionToken: string, userName: string, ra: string) => {
    localStorage.setItem("auth_sessionToken", sessionToken);
    localStorage.setItem("auth_userName", userName);
    localStorage.setItem("auth_ra", ra);
    setAuth({ sessionToken, userName, ra });
  };

  const logout = () => {
    localStorage.removeItem("auth_sessionToken");
    localStorage.removeItem("auth_userName");
    localStorage.removeItem("auth_ra");
    setAuth({ sessionToken: null, userName: null, ra: null });
  };

  return (
    <AuthContext.Provider value={{ ...auth, login, logout, isAuthenticated: !!auth.sessionToken }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
