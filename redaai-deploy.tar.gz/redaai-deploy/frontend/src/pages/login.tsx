import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useLoginUser } from "@/api";
import { useAuth } from "@/lib/auth";
import { useSettings } from "@/lib/settings";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Zap } from "lucide-react";

const loginSchema = z.object({
  ra: z.string().min(1, "RA é obrigatório"),
  password: z.string().min(1, "Senha é obrigatória"),
  digit: z.string().default(""),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function Login() {
  const [, setLocation] = useLocation();
  const { isAuthenticated, login } = useAuth();
  const { settings } = useSettings();
  const { toast } = useToast();
  const loginUser = useLoginUser();
  const [showPw, setShowPw] = useState(false);

  const form = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: { ra: "", password: "", digit: "" },
  });

  useEffect(() => {
    if (isAuthenticated) setLocation("/catalog");
  }, [isAuthenticated, setLocation]);

  const onSubmit = async (data: LoginForm) => {
    try {
      const result = await loginUser.mutateAsync({ data });
      if (result.success && result.sessionToken) {
        login(result.sessionToken, result.userName, result.ra);
        toast({
          title: "Login realizado!",
          description: `Bem-vindo, ${result.userName}`,
        });
        setLocation("/catalog");
      } else {
        toast({
          variant: "destructive",
          title: "Falha no login",
          description: result.message || "Credenciais inválidas",
        });
      }
    } catch (error: unknown) {
      const msg = (error as { response?: { data?: { error?: string } } })?.response?.data?.error
        || "Erro ao conectar. Verifique sua internet.";
      toast({ variant: "destructive", title: "Erro", description: msg });
    }
  };

  const primaryColor = settings?.primaryColor || "#e01c1c";

  return (
    <div className="flex-1 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Ambient glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `radial-gradient(ellipse at 50% 40%, ${primaryColor}12 0%, transparent 65%)`,
        }}
      />

      <div className="w-full max-w-md relative z-10">
        {/* Logo */}
        <div className="text-center mb-8">
          <h1
            className="text-5xl font-extrabold tracking-tight mb-2"
            style={{
              color: primaryColor,
              textShadow: `0 0 24px ${primaryColor}88, 0 0 48px ${primaryColor}33`,
            }}
          >
            {settings?.siteName || "RedaAI"}
          </h1>
          <p className="text-muted-foreground text-sm">
            Acesse sua conta e automatize suas redações
          </p>
        </div>

        <div
          className="rounded-2xl border bg-card/80 backdrop-blur-sm p-8 shadow-2xl"
          style={{ borderColor: `${primaryColor}25` }}
        >
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              <FormField
                control={form.control}
                name="ra"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-foreground/80 text-sm font-semibold">
                      RA (Registro do Aluno)
                    </FormLabel>
                    <FormControl>
                      <Input
                        data-testid="input-ra"
                        placeholder="Ex: 113636156xsp"
                        {...field}
                        className="h-12 bg-muted/40 border-border/60 focus:border-primary/60 text-foreground placeholder:text-muted-foreground/50"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-foreground/80 text-sm font-semibold">
                      Senha
                    </FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input
                          data-testid="input-password"
                          type={showPw ? "text" : "password"}
                          placeholder="••••••••"
                          {...field}
                          className="h-12 bg-muted/40 border-border/60 focus:border-primary/60 text-foreground pr-12 placeholder:text-muted-foreground/50"
                        />
                        <button
                          type="button"
                          onClick={() => setShowPw(!showPw)}
                          className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                        >
                          {showPw ? (
                            <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                              <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/>
                              <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/>
                              <line x1="1" y1="1" x2="23" y2="23"/>
                            </svg>
                          ) : (
                            <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                              <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/>
                              <circle cx="12" cy="12" r="3"/>
                            </svg>
                          )}
                        </button>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button
                data-testid="button-submit"
                type="submit"
                className="w-full h-12 text-base font-bold rounded-xl mt-2 transition-all duration-200"
                disabled={loginUser.isPending}
                style={{
                  background: `linear-gradient(135deg, hsl(340 80% 48%) 0%, hsl(340 85% 38%) 100%)`,
                  boxShadow: `0 0 16px hsl(340 80% 50% / 0.4), 0 2px 10px hsl(340 80% 30% / 0.4)`,
                  border: `1px solid hsl(340 80% 65% / 0.25)`,
                  color: "white",
                }}
              >
                {loginUser.isPending ? (
                  <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Entrando...</>
                ) : (
                  <><Zap className="mr-2 h-5 w-5" /> Acessar Plataforma</>
                )}
              </Button>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}
