import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  useGetAdminSettings,
  useUpdateAdminSettings,
  useUploadCreatorImage,
  getGetAdminSettingsQueryKey,
} from "@/api";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Upload, Loader2, Settings } from "lucide-react";

const settingsSchema = z.object({
  siteName:     z.string().min(1, "Obrigatório"),
  primaryColor: z.string().regex(/^#[0-9a-fA-F]{6}$/, "Cor inválida (ex: #e01c1c)"),
  footerText:   z.string().min(1, "Obrigatório"),
  creator1Name: z.string().min(1, "Obrigatório"),
  creator2Name: z.string().min(1, "Obrigatório"),
});
type SettingsForm = z.infer<typeof settingsSchema>;

export default function Admin() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: settings, isLoading } = useGetAdminSettings({
    query: { queryKey: getGetAdminSettingsQueryKey() },
  });

  const updateSettings = useUpdateAdminSettings();
  const uploadCreator  = useUploadCreatorImage();

  const [preview1, setPreview1] = useState<string | null>(null);
  const [preview2, setPreview2] = useState<string | null>(null);
  const file1Ref = useRef<HTMLInputElement>(null);
  const file2Ref = useRef<HTMLInputElement>(null);

  const form = useForm<SettingsForm>({
    resolver: zodResolver(settingsSchema),
    values: {
      siteName:     settings?.siteName     ?? "RedaAI",
      primaryColor: settings?.primaryColor ?? "#e01c1c",
      footerText:   settings?.footerText   ?? "Nami e tree script",
      creator1Name: settings?.creator1Name ?? "Nami",
      creator2Name: settings?.creator2Name ?? "JK",
    },
  });

  const onSubmit = async (data: SettingsForm) => {
    try {
      await updateSettings.mutateAsync({ data });
      queryClient.invalidateQueries({ queryKey: getGetAdminSettingsQueryKey() });
      toast({ title: "Salvo!", description: "Configurações atualizadas." });
    } catch {
      toast({ variant: "destructive", title: "Erro", description: "Falha ao salvar." });
    }
  };

  const handleFileUpload = (file: File, creatorIndex: number) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64 = e.target?.result as string;
      if (creatorIndex === 1) setPreview1(base64);
      else setPreview2(base64);
      try {
        await uploadCreator.mutateAsync({ data: { creatorIndex, imageBase64: base64 } });
        queryClient.invalidateQueries({ queryKey: getGetAdminSettingsQueryKey() });
        toast({ title: "Upload feito!", description: `Foto do Criador ${creatorIndex} atualizada.` });
      } catch {
        toast({ variant: "destructive", title: "Erro no upload", description: "Tente novamente." });
      }
    };
    reader.readAsDataURL(file);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <div className="flex items-center gap-3 mb-8">
        <button
          onClick={() => setLocation("/")}
          className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-muted/40 transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-2">
          <Settings className="h-5 w-5 text-primary" />
          <h1 className="text-2xl font-extrabold text-foreground">Painel Admin</h1>
        </div>
      </div>

      {/* Settings Form */}
      <div className="rounded-2xl border border-border/40 bg-card/70 backdrop-blur-sm p-6 mb-6">
        <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-5">
          Configurações do Site
        </p>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField control={form.control} name="siteName" render={({ field }) => (
              <FormItem>
                <FormLabel>Nome do Site</FormLabel>
                <FormControl>
                  <Input {...field} className="bg-muted/30 border-border/50 h-11" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />

            <FormField control={form.control} name="primaryColor" render={({ field }) => (
              <FormItem>
                <FormLabel>Cor Principal</FormLabel>
                <FormControl>
                  <div className="flex gap-3 items-center">
                    <Input {...field} placeholder="#e01c1c" className="bg-muted/30 border-border/50 h-11 flex-1" />
                    <input
                      type="color"
                      value={field.value}
                      onChange={(e) => field.onChange(e.target.value)}
                      className="h-11 w-14 rounded-lg border border-border/50 bg-transparent cursor-pointer p-1"
                    />
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />

            <FormField control={form.control} name="footerText" render={({ field }) => (
              <FormItem>
                <FormLabel>Texto do Rodapé</FormLabel>
                <FormControl>
                  <Input {...field} className="bg-muted/30 border-border/50 h-11" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )} />

            <div className="grid grid-cols-2 gap-4">
              <FormField control={form.control} name="creator1Name" render={({ field }) => (
                <FormItem>
                  <FormLabel>Nome — Criador 1</FormLabel>
                  <FormControl>
                    <Input {...field} className="bg-muted/30 border-border/50 h-11" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField control={form.control} name="creator2Name" render={({ field }) => (
                <FormItem>
                  <FormLabel>Nome — Criador 2</FormLabel>
                  <FormControl>
                    <Input {...field} className="bg-muted/30 border-border/50 h-11" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </div>

            <Button type="submit" className="w-full h-11 font-bold" disabled={updateSettings.isPending}>
              {updateSettings.isPending
                ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Salvando...</>
                : "Salvar Configurações"}
            </Button>
          </form>
        </Form>
      </div>

      {/* Creator photos */}
      <div className="rounded-2xl border border-border/40 bg-card/70 backdrop-blur-sm p-6">
        <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-5">
          Fotos dos Criadores
        </p>
        <div className="grid grid-cols-2 gap-6">
          {([1, 2] as const).map((idx) => {
            const currentSrc = idx === 1
              ? (preview1 || settings?.creator1Image || "/nami.jpg")
              : (preview2 || settings?.creator2Image || "/jk.jpg");
            const name = idx === 1
              ? (settings?.creator1Name || "Nami")
              : (settings?.creator2Name || "JK");
            const fileRef = idx === 1 ? file1Ref : file2Ref;

            return (
              <div key={idx} className="flex flex-col items-center gap-3">
                <div className="relative">
                  <img
                    src={currentSrc}
                    alt={name}
                    className="h-24 w-24 rounded-full object-cover border-2 border-border/50 shadow-lg"
                  />
                  <button
                    type="button"
                    onClick={() => fileRef.current?.click()}
                    className="absolute -bottom-1 -right-1 h-8 w-8 rounded-full flex items-center justify-center bg-card border border-border/60 hover:bg-muted transition-colors shadow"
                  >
                    <Upload className="h-3.5 w-3.5 text-muted-foreground" />
                  </button>
                </div>
                <span className="text-sm font-semibold text-foreground">{name}</span>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleFileUpload(file, idx);
                  }}
                />
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  className="text-xs text-muted-foreground hover:text-primary transition-colors underline underline-offset-2"
                >
                  Trocar foto
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
