import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { useSettings } from "@/lib/settings";
import {
  useListRedacoes,
  useCompletarRedacao,
} from "@/api";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  Loader2,
  Sparkles,
  CheckCircle2,
  FileText,
  Calendar,
  LogOut,
  RefreshCw,
} from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";

function StatusBadge({ status }: { status: string }) {
  const low = status.toLowerCase();
  const isDraft = low.includes("rascunho");
  const isDone  = low.includes("conclu") || low.includes("enviada") || low.includes("corrig");
  const isPending = low.includes("pendente");

  return (
    <Badge
      className="text-xs font-semibold border-0"
      style={
        isDone
          ? { background: "hsl(140 60% 22%)", color: "hsl(140 70% 65%)" }
          : isDraft
          ? { background: "hsl(220 60% 22%)", color: "hsl(220 70% 65%)" }
          : isPending
          ? { background: "hsl(30 60% 22%)", color: "hsl(30 90% 65%)" }
          : { background: "hsl(220 14% 18%)", color: "hsl(220 10% 60%)" }
      }
    >
      {status}
    </Badge>
  );
}

export default function Catalog() {
  const [, setLocation] = useLocation();
  const { isAuthenticated, sessionToken, userName, logout } = useAuth();
  const { settings } = useSettings();
  const { toast } = useToast();

  const [processingId, setProcessingId] = useState<string | null>(null);
  const [processingMsg, setProcessingMsg] = useState("Iniciando...");
  const [isDone, setIsDone] = useState(false);
  const [doneMsg, setDoneMsg] = useState("");
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const { data: essays, isLoading, refetch } = useListRedacoes(
    { sessionToken: sessionToken || "" },
    { query: { enabled: !!sessionToken && isAuthenticated } }
  );

  const completarMutation = useCompletarRedacao();

  if (!isAuthenticated) {
    setLocation("/");
    return null;
  }

  const handleProcess = async (essayId: string) => {
    if (!sessionToken) return;
    setProcessingId(essayId);
    setProcessingMsg("Aplicando redação...");
    setIsDone(false);
    setDoneMsg("");

    const steps = [
      { msg: "Aplicando redação...", delay: 0 },
      { msg: "Gerando texto com IA...", delay: 2500 },
      { msg: "Escrevendo parágrafos...", delay: 6000 },
      { msg: "Revisando coerência...", delay: 10000 },
      { msg: "Salvando rascunho...", delay: 14000 },
    ];

    for (const step of steps) {
      timerRef.current = setTimeout(() => setProcessingMsg(step.msg), step.delay);
    }

    try {
      const result = await completarMutation.mutateAsync({
        data: { id: essayId, sessionToken },
      });

      if (timerRef.current) clearTimeout(timerRef.current);

      if (result.success) {
        setDoneMsg(result.message);
        setIsDone(true);
        refetch();
      } else {
        setProcessingId(null);
        toast({ variant: "destructive", title: "Erro", description: result.message });
      }
    } catch (err: unknown) {
      if (timerRef.current) clearTimeout(timerRef.current);
      setProcessingId(null);
      const msg =
        (err as { response?: { data?: { error?: string } } })?.response?.data?.error ||
        "Erro ao processar. Tente novamente.";
      toast({ variant: "destructive", title: "Erro", description: msg });
    }
  };

  const handleClose = () => {
    setProcessingId(null);
    setIsDone(false);
    setDoneMsg("");
  };

  const handleLogout = () => {
    logout();
    setLocation("/");
  };

  const primaryColor = settings?.primaryColor || "#e01c1c";

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header row */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-foreground">
            Suas Redações
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Olá, <span className="font-semibold text-foreground">{userName}</span> — gerencie e complete suas atividades com IA.
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => refetch()}
            className="gap-2 border-border/60 bg-muted/30 hover:bg-muted/60"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Atualizar
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleLogout}
            className="gap-2 text-muted-foreground hover:text-foreground"
          >
            <LogOut className="h-3.5 w-3.5" />
            Sair
          </Button>
        </div>
      </div>

      {/* Content */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div
              key={i}
              className="rounded-xl border border-border/40 bg-card/60 p-6 animate-pulse"
            >
              <div className="h-4 bg-muted/50 rounded mb-3 w-1/3" />
              <div className="h-5 bg-muted/50 rounded mb-2" />
              <div className="h-4 bg-muted/30 rounded w-2/3 mb-6" />
              <div className="h-10 bg-muted/30 rounded-lg" />
            </div>
          ))}
        </div>
      ) : essays?.length === 0 || !essays ? (
        <div className="text-center py-20 rounded-2xl border border-dashed border-border/40 bg-card/30">
          <FileText className="mx-auto h-14 w-14 text-muted-foreground/30 mb-4" />
          <h3 className="text-lg font-semibold text-foreground/80">Nenhuma redação encontrada</h3>
          <p className="text-muted-foreground text-sm mt-1">
            Você não tem atividades pendentes ou rascunhos no momento.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {essays.map((essay) => {
            const isDoneStatus =
              essay.status.toLowerCase().includes("conclu") ||
              essay.status.toLowerCase().includes("enviada") ||
              essay.status.toLowerCase().includes("corrig");

            return (
              <div
                key={essay.id}
                data-testid={`card-essay-${essay.id}`}
                className="rounded-xl border bg-card/70 backdrop-blur-sm flex flex-col transition-all duration-200 hover:shadow-lg"
                style={{ borderColor: `${primaryColor}18` }}
              >
                <div className="p-5 flex-1">
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <StatusBadge status={essay.status} />
                    {essay.nota && (
                      <span
                        className="text-xs font-bold px-2 py-0.5 rounded-full"
                        style={{
                          background: `${primaryColor}20`,
                          color: primaryColor,
                        }}
                      >
                        Nota: {essay.nota}
                      </span>
                    )}
                  </div>

                  <h3 className="font-bold text-foreground leading-snug line-clamp-2 text-base mb-2">
                    {essay.titulo}
                  </h3>

                  {essay.dataEnvio && (
                    <p className="flex items-center gap-1.5 text-xs text-muted-foreground mb-3">
                      <Calendar className="h-3 w-3" />
                      {essay.dataEnvio}
                    </p>
                  )}

                  {essay.tema && (
                    <p className="text-xs text-muted-foreground/80 bg-muted/30 rounded-lg px-3 py-2 border border-border/30 line-clamp-3">
                      {essay.tema}
                    </p>
                  )}
                </div>

                <div className="px-5 pb-5">
                  <button
                    data-testid={`button-fazer-${essay.id}`}
                    onClick={() => !isDoneStatus && !processingId && handleProcess(essay.id)}
                    disabled={!!processingId || isDoneStatus}
                    className="w-full h-11 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                    style={
                      isDoneStatus
                        ? {
                            background: "hsl(220 14% 16%)",
                            color: "hsl(220 10% 50%)",
                            border: "1px solid hsl(220 13% 22%)",
                          }
                        : {
                            background: `linear-gradient(135deg, hsl(340 80% 48%) 0%, hsl(340 85% 38%) 100%)`,
                            boxShadow: `0 0 14px hsl(340 80% 50% / 0.35), 0 2px 8px hsl(340 80% 30% / 0.3)`,
                            border: `1px solid hsl(340 80% 65% / 0.2)`,
                            color: "white",
                          }
                    }
                  >
                    {isDoneStatus ? (
                      <><CheckCircle2 className="h-4 w-4" /> Já Concluída</>
                    ) : processingId === essay.id ? (
                      <><Loader2 className="h-4 w-4 animate-spin" /> Processando...</>
                    ) : (
                      <><Sparkles className="h-4 w-4" /> Fazer Redação com IA</>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Processing Modal */}
      <Dialog
        open={!!processingId}
        onOpenChange={(open) => {
          if (!open && isDone) handleClose();
        }}
      >
        <DialogContent className="sm:max-w-md text-center p-8 border-border/40 bg-card/95 backdrop-blur-md outline-none">
          {isDone ? (
            <div className="flex flex-col items-center animate-in zoom-in-95 duration-300">
              <div
                className="h-20 w-20 rounded-full flex items-center justify-center mb-6"
                style={{ background: "hsl(140 60% 12%)", border: "2px solid hsl(140 60% 35%)" }}
              >
                <CheckCircle2 className="h-10 w-10" style={{ color: "hsl(140 70% 55%)" }} />
              </div>
              <h2 className="text-2xl font-extrabold mb-2 text-foreground">
                Redação Concluída!
              </h2>
              <p className="text-muted-foreground text-sm mb-8">
                {doneMsg || "Sua redação foi gerada e salva como rascunho na plataforma!"}
              </p>
              <button
                onClick={handleClose}
                className="w-full h-12 rounded-xl font-bold text-base text-white"
                style={{
                  background: `linear-gradient(135deg, hsl(340 80% 48%) 0%, hsl(340 85% 38%) 100%)`,
                  boxShadow: `0 0 16px hsl(340 80% 50% / 0.4)`,
                }}
              >
                Voltar ao Catálogo
              </button>
            </div>
          ) : (
            <div className="flex flex-col items-center">
              {/* Animated spinner */}
              <div className="relative h-24 w-24 mb-8 mt-2">
                <div
                  className="absolute inset-0 rounded-full border-4"
                  style={{ borderColor: `${primaryColor}20` }}
                />
                <div
                  className="absolute inset-0 rounded-full border-4 border-t-transparent animate-spin"
                  style={{ borderColor: `${primaryColor} transparent transparent transparent` }}
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Sparkles
                    className="h-9 w-9 animate-pulse"
                    style={{ color: primaryColor }}
                  />
                </div>
              </div>
              <h2 className="text-2xl font-extrabold text-foreground mb-3">
                Processando com IA
              </h2>
              <p
                className="text-base font-semibold animate-pulse mb-1"
                style={{ color: primaryColor }}
              >
                {processingMsg}
              </p>
              <p className="text-xs text-muted-foreground mt-4">
                Por favor, não feche esta janela.
              </p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
