# RedaAI — Guia de Hospedagem

## Como hospedar no Netlify + Railway/Render

### 1. Backend (Railway, Render ou Heroku)

```bash
cd backend
npm install
npm run dev  # para desenvolvimento
npm start    # para produção
```

Defina a variável de ambiente PORT se necessário.

### 2. Frontend (Netlify)

1. Edite `netlify.toml` e substitua `YOUR-BACKEND-URL.railway.app` pela URL do seu backend
2. Na pasta `frontend/`, instale dependências: `npm install`
3. Faça build: `npm run build`
4. Faça upload da pasta `dist/` no Netlify, ou conecte o repositório

### Painel Admin
- Clique 5 vezes no título "RedaAI" para abrir o painel admin
- Senha: 1704

### Criadores
- Nami: imagem já incluída em `public/nami.jpg`
- JK: faça upload pela interface admin
